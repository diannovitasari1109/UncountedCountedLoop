/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uncounted.counted.loop;

/**
 *
 * @author DNS
 */
import java.util.Scanner;
public class UncountedCountedLoop {
    
    static void perfor(){
        for (int hitungan = 0;hitungan<=10;hitungan++){
            System.out.println("*****");
        }
    }
    
    static void perang(){
        for (int i = 0;i<=10;i++){
            System.out.println(i+"");
        }   
    }
    
    static void pergan(){
        for (int i =1 ; i<=20 ;i+=2){
            System.out.println(i+"");
        }   
    }
    
    static void foreach(){
        int angka[]={3,1,14,15,5,2};
        for (int x:angka){
            System.out.println(x+"");
        }   
    }
    
    static void perUncountedwhile(){
        boolean berjalan = true;
        int hitung = 0;
        String jawab;
        
        Scanner jawaban = new Scanner(System.in);
        
        while(berjalan){
            System.out.println("Apakah anda ingin keluar?");
            System.out.println("Jawab[Ya/Tidak]");
            
            jawab = jawaban.nextLine();
            
            if (jawab.equalsIgnoreCase("ya")){
                berjalan = false;
            }
            hitung++;
        }
        System.out.println("Anda melakukan perulangan sebanyak "+hitung+"x");
    }
    
    static void perwhile(){
        int i= 0;
        
        while ( i <= 10){
            System.out.println("Perulangan ke-"+i);
            i++;
        }
    }
    
    static void perDoWhile(){
        int i =0;
        
        do{
            System.out.println("Perulangan ke-"+i);
            
        }while(i<=10);
    }
    
    static void perbers(){
        int x,y;
        
        for (x=0;x<=5;x++){
            for(y=0;y<=3;y++){
                System.out.format("Perulangan [x=%d,y=%d]%n",x,y);
            }
        
        }
    }

    /**
     * 1. Program perulangan menampilkan bintang(perfor)
     * 2. Program perulangan menampilkan angka(perang)
     * 3. Program perulangan menampilkan angka ganjil(pergan)
     * 4. Program perulangan for each menampilkan array(foreach)
     * 
     * Uncounted loop
     * 
     * 5. Program perulangan while uncounted loop
     * 
     * 6. Perulangan While
     * 7. Perulangan Do While
     * 
     * 8. Perulangan Bersarang
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);
        Scanner ulang = new Scanner(System.in);
        String ulang2;
        int inputan;
        
        boolean ulangi = true;
        
        do{
        System.out.println(
            "Counted Loop\n"+
            "\n"+
            "1. Program perulangan menampilkan bintang\n" +
            "2. Program perulangan menampilkan angka\n" +
            "3. Program perulangan menampilkan angka ganjil\n" +
            "4. Program perulangan for each menampilkan array\n" +
            "\n" +
            "Uncounted loop\n" +
            "\n" +
            "5. Program perulangan while uncounted loop\n" +
            "\n" +
            "6. Perulangan While\n" +
            "7. Perulangan Do While\n" +
            "\n" +
            "8. Perulangan Bersarang");
        System.out.println("Masukan angka");
        
        inputan=input.nextInt();
        
        if (inputan == 1){
            perfor();
        }else if (inputan == 2){
            perang();
        }else if (inputan == 3){
            pergan();
        }else if (inputan == 4){
            foreach();
        }else if (inputan == 5){
            perUncountedwhile();
        }else if (inputan == 6){
            perwhile();
        }else if (inputan == 7){
            perDoWhile();
        }else if (inputan == 8){
            perbers();
        }
        
        System.out.println("Apakah anda ingin mengulanginya lagi?[YA/TIDAK]");
        ulang2 = ulang.nextLine();
        
        if (ulang2.equalsIgnoreCase("ya")){
            ulangi = true;
        }else if (ulang2.equalsIgnoreCase("tidak")){
            ulangi = false;
        }
        
        
        }while (ulangi);
        
        
        
        
    }
    
}
